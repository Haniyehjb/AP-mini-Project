// game_manager.cpp
#include "game_manager.h"
#include <iostream>
#include <fstream>
#include <thread>
#include <cstdlib>
#include <windows.h>

game_manager* game_manager::_instance = nullptr;

game_manager* game_manager::instance() {
    if (!_instance) {
        _instance = new game_manager();
    }
    return _instance;
}

void game_manager::set_map_name(std::string _map_name) { map_name = _map_name; }
void game_manager::set_game_result(int _game_result) { game_result = _game_result; }
std::string game_manager::get_map_name() { return map_name; }
int game_manager::get_game_result() { return game_result; }

void game_manager::add_ct_player(const player& p) { team_ct.push_back(p); }
void game_manager::add_terrorist_player(const player& p) { team_terrorist.push_back(p); }

void game_manager::setting_menu() {
    int num_ct, num_terrorist;
    std::cout << "Enter number of CT players: ";
    std::cin >> num_ct;
    std::cout << "Enter number of Terrorist players: ";
    std::cin >> num_terrorist;

    // تنظیمات بازیکنان
    for (int i = 0; i < num_ct; ++i) {
        player p("CT_Player" + std::to_string(i + 1));
        p.set_money(800);
        add_ct_player(p);
    }
    for (int i = 0; i < num_terrorist; ++i) {
        player p("Terrorist_Player" + std::to_string(i + 1));
        p.set_money(800);
        add_terrorist_player(p);
    }
}

void game_manager::start_game() {
    while (terroristIndex < team_terrorist.size() && ctIndex < team_ct.size()) {
        player& terroristPlayer = team_terrorist[terroristIndex];
        player& ctPlayer = team_ct[ctIndex];

        double terroristPower = terroristPlayer.calculate_power();
        double ctPower = ctPlayer.calculate_power();

        if (terroristPower > ctPower) {
            ctPlayer.set_health(ctPlayer.get_health() - 10);
            if (ctPlayer.get_health() <= 0) ctIndex++;
        } else if (ctPower > terroristPower) {
            terroristPlayer.set_health(terroristPlayer.get_health() - 10);
            if (terroristPlayer.get_health() <= 0) terroristIndex++;
        } else {
            ctPlayer.set_health(ctPlayer.get_health() - 5);
            terroristPlayer.set_health(terroristPlayer.get_health() - 5);
            if (ctPlayer.get_health() <= 0) ctIndex++;
            if (terroristPlayer.get_health() <= 0) terroristIndex++;
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(500));
    }
    checkWinner();
}

void game_manager::checkWinner() {
    if (terroristIndex >= team_terrorist.size()) {
        std::cout << "CT team wins!" << std::endl;
        game_result = 1;
    } else if (ctIndex >= team_ct.size()) {
        std::cout << "Terrorist team wins!" << std::endl;
        game_result = 0;
    } else {
        decideTieBreaker();
    }
}

void game_manager::decideTieBreaker() {
    srand(time(nullptr));
    if (rand() % 2 == 0) {
        std::cout << "Terrorist team wins by random decision!" << std::endl;
        game_result = 0;
    } else {
        std::cout << "CT team wins by random decision!" << std::endl;
        game_result = 1;
    }
}

int game_manager::display_history(const std::string& filename, const std::string& userid) {
    std::ifstream file(filename);
    if (!file.is_open()) {
        std::cerr << "Error: Cannot open file!" << std::endl;
        return -1;
    }

    int user_wins = 0;
    std::string line;
    while (std::getline(file, line)) {
        for (char c : line) {
            if (c == '0') {
                for (const auto& p : team_terrorist) {
                    if (p.get_id() == userid) user_wins++;
                }
            } else if (c == '1') {
                for (const auto& p : team_ct) {
                    if (p.get_id() == userid) user_wins++;
                }
            }
        }
    }
    return user_wins;
}