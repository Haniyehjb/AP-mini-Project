#include "gun.h"
#include <string>


std::string generate_guid() {
    UUID uuid;
    UuidCreate(&uuid);
    unsigned char* str;
    UuidToStringA(&uuid, &str);
    std::string guid(reinterpret_cast<char*>(str));
    RpcStringFreeA(&str);
    return guid;
}

gun::gun() : num_shot(0), price(0), gun_id(generate_guid()), gun_name(AK47), power_shot(0), num_gun(0) {}

gun::gun(const gun& obj)
    : num_shot(obj.num_shot), price(obj.price), gun_id(obj.gun_id),
      gun_name(obj.gun_name), power_shot(obj.power_shot), num_gun(obj.num_gun) {}

gun::gun(int _num_shot, int _price, std::string _gun_id, Guns _gun_name, int _power_shot, int _num_gun)
    : num_shot(_num_shot), price(_price), gun_id(_gun_id), gun_name(_gun_name),
      power_shot(_power_shot), num_gun(_num_gun) {}

gun& gun::operator=(const gun& obj) {
    num_shot = obj.num_shot;
    price = obj.price;
    gun_id = obj.gun_id;
    gun_name = obj.gun_name;
    power_shot = obj.power_shot;
    num_gun = obj.num_gun;
    return *this;
}

bool gun::operator!=(const gun& obj) { return !(*this == obj); }
bool gun::operator==(const gun& obj) {
    return num_shot == obj.num_shot &&
           price == obj.price &&
           gun_id == obj.gun_id &&
           gun_name == obj.gun_name &&
           power_shot == obj.power_shot &&
           num_gun == obj.num_gun;
}

gun::~gun() { num_gun--; }

std::string gun::getGunName(Guns gun) {
    switch (gun) {
        case AK47: return "AK-47";
        case M4A1: return "M4A1";
        case AWP: return "AWP";
        case P90: return "P90";
        case UMP45: return "UMP-45";
        case FAMAS: return "FAMAS";
        case DESERT_EAGLE: return "Desert Eagle";
        case GLOCK: return "Glock";
        case MP5: return "MP5";
        case SHOTGUN: return "Shotgun";
        default: return "Unknown Gun";
    }
}