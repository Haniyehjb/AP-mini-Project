#include "player.h"
#include <iostream>
#include <sstream>

// تابع تولید GUID
std::string generate_guid() {
    UUID uuid;
    UuidCreate(&uuid);
    unsigned char* str;
    UuidToStringA(&uuid, &str);
    std::string guid(reinterpret_cast<char*>(str));
    RpcStringFreeA(&str);
    return guid;
}

// سازنده‌ها و متد‌ها
player::player(std::string playerName, int initialScore) : name(playerName), score(initialScore) {
    id = "P" + generate_guid(); 
    using_gun_id = "";
    using_gun_name = AK47; 
    health = 100;          
    armor = 50;            
    AI = false;            
    money = 800;           
    phead = nullptr;
}

void player::set_id(std::string _id) { id = _id; }
void player::set_name(std::string _name) { name = _name; }
void player::set_using_gun_id(std::string _using_gun_id) { using_gun_id = _using_gun_id; }
void player::set_using_gun_name(Guns _using_gun_name) { using_gun_name = _using_gun_name; }
void player::set_health(int _health) { health = _health; }
void player::set_armor(int _armor) { armor = _armor; }
void player::set_AI(bool _ai) { AI = _ai; }
void player::set_money(int _money) { money = _money; }
void player::set_score(int _score) { score = _score; }

std::string player::get_id() { return id; }
std::string player::get_name() { return name; }
std::string player::get_using_gun_id() { return using_gun_id; }
Guns player::get_using_gun_name() { return using_gun_name; }
int player::get_health() { return health; }
int player::get_armor() { return armor; }
bool player::get_AI() { return AI; }
int player::get_money() { return money; }
int player::get_score() { return score; }

double player::calculate_power() const {
    double power = money;
    if (using_gun_name != Guns{}) { 
        gun g;
        g.set_num_shot(30);         
        g.set_power_shot(35);
        power += g.get_num_shot() * g.get_power_shot();
    }
    return power;
}

node* player::add_node(const player& p) {
    node* pnew = new node;
    pnew->data = p;
    pnew->pnxt = nullptr;
    pnew->pprv = nullptr;
    if (!phead) {
        phead = pnew;
        pnew->pnxt = pnew;
        pnew->pprv = pnew;
    } else {
        node* last = phead->pprv;
        last->pnxt = pnew;
        pnew->pprv = last;
        pnew->pnxt = phead;
        phead->pprv = pnew;
    }
    return pnew;
}

void player::delete_node(Guns _guns) {
    if (!phead) {
        std::cout << "Error: No member to delete." << std::endl;
        return;
    }
    node* ptmp = phead;
    do {
        if (ptmp->data.get_using_gun_name() == _guns) {
            if (ptmp == phead) {
                if (ptmp->pnxt == phead) {
                    delete ptmp;
                    phead = nullptr;
                } else {
                    node* last = phead->pprv;
                    phead = ptmp->pnxt;
                    last->pnxt = phead;
                    phead->pprv = last;
                    delete ptmp;
                }
            } else {
                node* before = ptmp->pprv;
                node* after = ptmp->pnxt;
                before->pnxt = after;
                after->pprv = before;
                delete ptmp;
            }
            return;
        }
        ptmp = ptmp->pnxt;
    } while (ptmp != phead);
    std::cout << "Not found." << std::endl;
}

// سازنده‌های کپی و عملگرهای تخصیص
player::player() : id(""), name(""), using_gun_id(""), using_gun_name(AK47),
                   health(0), armor(0), AI(false), money(0), score(0), phead(nullptr) {}

player::player(const player& obj)
    : id(obj.id), name(obj.name), using_gun_id(obj.using_gun_id),
      using_gun_name(obj.using_gun_name), health(obj.health), armor(obj.armor),
      AI(obj.AI), money(obj.money), score(obj.score), phead(nullptr) {}

player::player(std::string _id, std::string _name, std::string _using_gun_id, Guns _using_gun_name,
               int _health, int _armor, bool _AI, int _money)
    : id(_id), name(_name), using_gun_id(_using_gun_id), using_gun_name(_using_gun_name),
      health(_health), armor(_armor), AI(_AI), money(_money), score(0), phead(nullptr) {}

player& player::operator=(const player& obj) {
    id = obj.id;
    name = obj.name;
    using_gun_id = obj.using_gun_id;
    using_gun_name = obj.using_gun_name;
    health = obj.health;
    armor = obj.armor;
    AI = obj.AI;
    money = obj.money;
    score = obj.score;
    return *this;
}

bool player::operator!=(const player& obj) { return !(*this == obj); }
bool player::operator==(const player& obj) {
    return id == obj.id && name == obj.name && using_gun_id == obj.using_gun_id &&
           using_gun_name == obj.using_gun_name && health == obj.health &&
           armor == obj.armor && AI == obj.AI && money == obj.money && score == obj.score;
}