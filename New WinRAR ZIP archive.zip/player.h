#ifndef PLAYER_H
#define PLAYER_H

#include <string>
#include "gun.h"

class node;

class player {
private:
    std::string id;
    std::string name;
    std::string using_gun_id;
    Guns using_gun_name;
    int health;
    int armor;
    bool AI;
    int money;
    int score;
    node* phead;

public:
    player(std::string playerName, int initialScore = 0);
    void set_id(std::string);
    void set_name(std::string);
    void set_using_gun_id(std::string);
    void set_using_gun_name(Guns);
    void set_health(int);
    void set_armor(int);
    void set_AI(bool);
    void set_money(int);
    void set_score(int);
    std::string get_id();
    std::string get_name();
    std::string get_using_gun_id();
    Guns get_using_gun_name();
    int get_health();
    int get_armor();
    bool get_AI();
    int get_money();
    int get_score();

    double calculate_power() const;
    node* add_node(const player& p);
    void delete_node(Guns _guns);

    player();
    player(const player& obj);
    player(std::string _id, std::string _name, std::string _using_gun_id, Guns _using_gun_name,
           int _health, int _armor, bool _AI, int _money);
    player& operator=(const player& obj);
    bool operator!=(const player& obj);
    bool operator==(const player& obj);
};

#endif // PLAYER_H