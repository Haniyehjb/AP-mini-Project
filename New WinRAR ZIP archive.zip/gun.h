#ifndef GUN_H
#define GUN_H

#include <string>

enum Guns {
    AK47 = 1,
    M4A1,
    AWP,
    P90,
    UMP45,
    FAMAS,
    DESERT_EAGLE,
    GLOCK,
    MP5,
    SHOTGUN
};

class gun {
private:
    int num_shot;
    int price;
    std::string gun_id;
    Guns gun_name;
    int power_shot;
    int num_gun;

public:
    void set_num_shot(int);
    void set_price(int);
    void set_gun_id(std::string);
    void set_gun_name(Guns);
    void set_power_shot(int);
    void set_num_gun(int);
    int get_num_shot();
    int get_price();
    std::string get_gun_id();
    Guns get_gun_name();
    int get_power_shot();
    int get_num_gun();

    gun();
    gun(const gun& obj);
    gun(int _num_shot, int _price, std::string _gun_id, Guns _gun_name, int _power_shot, int _num_gun);
    ~gun();
    gun& operator=(const gun& obj);
    bool operator!=(const gun& obj);
    bool operator==(const gun& obj);
    std::string getGunName(Guns gun);
};

#endif // GUN_H