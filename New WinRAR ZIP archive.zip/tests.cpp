// tests.cpp
#include "test_framework.h"
#include "gun.h"      
#include "player.h"    
#include "game_manager.h" r

class GunBasicTest : public TestCase {
public:
    GunBasicTest() { name = "GunBasicTest"; }
    
    void run() override {
        gun g;
        g.set_num_shot(30);
        g.set_price(2700);
        g.set_gun_name(AK47);
        g.set_power_shot(35);
        
        if (g.get_num_shot() != 30) throw "num_shot failed";
        if (g.get_price() != 2700) throw "price failed";
        if (g.get_gun_name() != AK47) throw "gun_name failed";
        if (g.get_power_shot() != 35) throw "power_shot failed";
        
        passed = true;
    }
};

class PlayerHealthTest : public TestCase {
public:
    PlayerHealthTest() { name = "PlayerHealthTest"; }
    
    void run() override {
        player p("TestPlayer");
        p.set_health(100);
        p.set_health(p.get_health() - 30);
        
        if (p.get_health() != 70) throw "health subtraction failed";
        
        p.set_health(-10);
        if (p.get_health() < 0) throw "negative health not handled";
        
        passed = true;
    }
};

class GameManagerTest : public TestCase {
public:
    GameManagerTest() { name = "GameManagerTest"; }
    
    void run() override {
        game_manager* gm = game_manager::instance();
        gm->add_ct_player(player("CT1"));
        gm->add_terrorist_player(player("T1"));
        
        if (gm->get_team_ct().size() != 1) throw "CT team size incorrect";
        if (gm->get_team_terrorist().size() != 1) throw "Terrorist team size incorrect";
        
        passed = true;
    }
};