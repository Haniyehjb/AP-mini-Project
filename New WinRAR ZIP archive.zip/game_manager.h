// game_manager.h
#ifndef GAME_MANAGER_H
#define GAME_MANAGER_H

#include <vector>
#include <string>
#include "player.h"

class game_manager {
private:
    std::vector<player> team_ct;
    std::vector<player> team_terrorist;
    int game_result;
    std::string map_name;
    static game_manager* _instance;
    int terroristIndex;
    int ctIndex;

    game_manager() : map_name(""), game_result(0), terroristIndex(0), ctIndex(0) {}
    void decideTieBreaker();

public:
    static game_manager* instance();
    void set_map_name(std::string);
    void set_game_result(int);
    std::string get_map_name();
    int get_game_result();
    void add_ct_player(const player& p);
    void add_terrorist_player(const player& p);
    void setting_menu();
    void start_game();
    void checkWinner();
    int display_history(const std::string& filename, const std::string& userid);
};

#endif // GAME_MANAGER_H