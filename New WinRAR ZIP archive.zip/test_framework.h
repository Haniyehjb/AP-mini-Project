// test_framework.h
#ifndef TEST_FRAMEWORK_H
#define TEST_FRAMEWORK_H

#include <iostream>
#include <string>
#include <vector>

class TestCase {
public:
    virtual void run() = 0;
    std::string name;
    bool passed;
};

class TestRunner {
private:
    std::vector<TestCase*> tests;
    int passed = 0;
    int failed = 0;

public:
    void addTest(TestCase* test) {
        tests.push_back(test);
    }

    void runAll() {
        std::cout << "Running " << tests.size() << " tests...\n";
        for (auto test : tests) {
            std::cout << "Running test: " << test->name << "... ";
            try {
                test->run();
                if (test->passed) {
                    std::cout << "PASSED\n";
                    passed++;
                } else {
                    std::cout << "FAILED\n";
                    failed++;
                }
            } catch (...) {
                std::cout << "CRASHED\n";
                failed++;
            }
        }

        std::cout << "\nTest results:\n";
        std::cout << "  Passed: " << passed << "\n";
        std::cout << "  Failed: " << failed << "\n";
        std::cout << "  Total:  " << tests.size() << "\n";
    }
};

#endif // TEST_FRAMEWORK_H