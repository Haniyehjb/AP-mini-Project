#include <iostream>
#include <vector>
#include <string>
#include <windows.h>
#include <rpc.h>
#include <cstdlib>
#include <fstream>
#include <functional>
#include <random>
#include <thread>
#include <cassert>
#include <ctime>
#include <windows.h>
#include <wincrypt.h>
#include <sstream>
#include <iomanip>
using namespace std;

#pragma comment(lib, "rpcrt4.lib")


string generate_guid() {
    UUID uuid;
    UuidCreate(&uuid);
    unsigned char* str;
    UuidToStringA(&uuid, &str);
    string guid(reinterpret_cast<char*>(str));
    RpcStringFreeA(&str);
    return guid;
}


int main(int argc, char* argv[]) {
    
    for (int i = 1; i < argc; i++) {
        if (std::string(argv[i]) == "--test") {
            TestRunner runner;
            
         
            runner.addTest(new GunBasicTest());
            runner.addTest(new PlayerHealthTest());
            runner.addTest(new GameManagerTest());
            
       
            runner.runAll();
            return 0;
        }
    }

  
    std::cout << "Starting the game..." << std::endl;
   
    return 0;
}